# Sun & Wind Lab + Lifecycle Takeoff

Two self-contained architecture experiments. Both are static sites (HTML, JS, CSS and data) with no build step, so they run on any static host: Netlify, Vercel, Cloudflare Pages, GitHub Pages, S3 or a plain web server.

- **sun-wind-lab/**: solar and shadow analysis, sun hours, façade irradiance, a live lattice-Boltzmann wind tunnel, Lawson wind comfort, thermal comfort and a façade energy model. The test case is the Seagram Building block.
- **lifecycle-takeoff/**: reads a building from an address, a 3D model (Rhino .3dm, OBJ, IFC, glTF/GLB, STL) or drawings (PDF, SVG, DXF, scans). It splits the building into components and builds a whole-life carbon (EPD) table across modules A–D, including operational carbon.

## Install

1. Copy both folders into your site's public/root folder, so they're served at
   `yoursite.com/sun-wind-lab/` and `yoursite.com/lifecycle-takeoff/`.
   They can also go in a subfolder, because every path is relative. Keep the two folders side by side, since Sun & Wind Lab links to Lifecycle Takeoff.
2. Open each folder's URL **with the trailing slash**, e.g. `/lifecycle-takeoff/` and not `/lifecycle-takeoff`.
3. Link to them from your nav. The logo's "back home" link in each page points to `/`.

To test locally, run `python3 -m http.server` in this folder and open http://localhost:8000/sun-wind-lab/.
Don't open the files by double-clicking, because ES modules need to be served over http.

Three.js, pdf.js, web-ifc and the world map load from the jsDelivr CDN. Lifecycle Takeoff's address lookup uses OpenStreetMap Nominatim.

## Optional features

Everything works without these. Without them, two buttons show a short message instead of doing their job.

**Photoreal button in Sun & Wind Lab (Google Photorealistic 3D Tiles)**
- Create a Google Maps Platform key with the **Map Tiles API** enabled, and restrict it to your domain (HTTP referrer).
- Paste the key into `sun-wind-lab/index.html`: `window.GOOGLE_MAPS_KEY = "your-key";`
- If you'd rather keep the key out of the HTML, serve it from `/api/earth-twin/config` instead. A Cloudflare Pages version is in `optional-backend/`.

**AI reading of scanned or raster drawings in Lifecycle Takeoff**
- Vector drawings (SVG, DXF, vector PDFs) are read in the browser. Only scans and photos of sheets need the AI endpoint `/api/plan-read`.
- `optional-backend/functions/` holds a Cloudflare Pages Function that uses Workers AI (Llama 4 Scout vision). To use it, copy that `functions/` folder into the root of a Cloudflare Pages project and add a Workers AI binding named `AI` in the project settings.
- The endpoint has no auth or rate limit. If the site is public, add a limit (for example a Cloudflare rate-limiting rule on `/api/plan-read`) so strangers can't run up the AI bill.
- On another host, write any endpoint that accepts `POST {image, text}` and returns `{ok: true, read: {...}}`. See `plan-read.js` for the schema.

## Credits

The photographs in `lifecycle-takeoff/img/` come from Wikimedia Commons under CC0, public domain, CC BY and CC BY-SA licences. Each image's author, licence and source link are in `lifecycle-takeoff/media-data.js` and appear in the app. Keep those credits if you reuse the images.

Built by Rolando Vega (vega.design).
