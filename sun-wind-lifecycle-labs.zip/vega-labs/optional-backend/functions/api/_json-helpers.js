// JSON helpers for plan-read.js (lifted from the source site's vision helper).
export function textOf(r) {
  const v = r?.response ?? r?.result?.response ?? r?.choices?.[0]?.message?.content ?? r?.output_text ?? r;
  return typeof v === 'string' ? v : v && typeof v === 'object' ? JSON.stringify(v) : String(v ?? '');
}

export function parseJson(raw) {
  const v = raw?.response ?? raw?.result?.response ?? raw?.choices?.[0]?.message?.content ?? raw?.output_text ?? raw;
  if (v && typeof v === 'object' && !Array.isArray(v)) return v;
  let t = String(v ?? '').replace(/<think>[\s\S]*?<\/think>/g, '').replace(/```(?:json)?/gi, '');
  const a = t.indexOf('{');
  if (a < 0) return null;
  t = t.slice(a);
  try { return JSON.parse(t.slice(0, t.lastIndexOf('}') + 1)); } catch { /* fall through to repair */ }
  return repairJson(t);
}

export function repairJson(t) {
  let s = t.replace(/,\s*$/, '');
  for (let k = 0; k < 6; k++) {
    let inStr = false, esc = false; const stack = [];
    for (const ch of s) {
      if (esc) { esc = false; continue; }
      if (ch === '\\') { esc = true; continue; }
      if (ch === '"') inStr = !inStr;
      else if (!inStr && (ch === '{' || ch === '[')) stack.push(ch);
      else if (!inStr && (ch === '}' || ch === ']')) stack.pop();
    }
    let c = s + (inStr ? '"' : '');
    c = c.replace(/,\s*"[^"]*"?\s*:?\s*"?$/, '').replace(/,\s*$/, '').replace(/:\s*$/, ': null');
    for (let i = stack.length - 1; i >= 0; i--) c += stack[i] === '{' ? '}' : ']';
    try { return JSON.parse(c); } catch { s = s.slice(0, Math.max(0, s.lastIndexOf(',', s.length - 2))); }
  }
  return null;
}

