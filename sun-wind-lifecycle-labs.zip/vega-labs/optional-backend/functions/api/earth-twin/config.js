// Serves the Google Maps key to Sun & Wind Lab (only needed if you'd rather not put the key in index.html).
// Set GOOGLE_MAPS_KEY as an environment secret in Cloudflare Pages.
export async function onRequest({ env }) {
  return new Response(JSON.stringify({ googleKey: env.GOOGLE_MAPS_KEY || null }), {
    headers: { 'content-type': 'application/json', 'cache-control': 'private, max-age=300' }
  });
}
