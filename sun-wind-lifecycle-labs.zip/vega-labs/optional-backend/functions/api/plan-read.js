// Lifecycle Takeoff · AI read of a raster drawing (scanned plan, photo of a sheet, PDF page rendered in the browser).
// Vector drawings (SVG, DXF) are read in the browser by geometry; this endpoint handles what geometry cannot: pixels.
// The model reports what is printed on the sheet — dimension strings, counts, labels, notes — and the server converts
// dimension strings to metres itself, so the numbers that reach the takeoff come from the drawing's own text.
import { parseJson, textOf } from './_json-helpers.js';

const VISION_MODEL = '@cf/meta/llama-4-scout-17b-16e-instruct';
const MAX_IMAGE_CHARS = 2_600_000;
const CATEGORIES = ['foundations', 'columns', 'beams', 'slabs', 'cores', 'walls', 'curtain wall', 'windows', 'doors', 'stairs', 'lifts', 'roof', 'finishes', 'services', 'site', 'other'];

const PROMPT = `You are a quantity surveyor reading one architectural drawing sheet. Report only what is drawn or printed. Return one JSON object, no prose:
{"sheetType": one of "floor plan"|"site plan"|"section"|"elevation"|"detail"|"other",
 "title": the sheet title as printed, "sheetNumber": e.g. "A-111",
 "scaleText": scale as printed or "",
 "dimensionsRead": [up to 14 dimension strings exactly as printed, e.g. "27'-9\\"" or "8400"],
 "grid": {"linesAcross": number of column grid lines left to right, "linesDeep": number top to bottom, "bayAcross": the repeated bay dimension string across, "bayDeep": the repeated bay dimension string top to bottom},
 "floorPlate": {"width": overall width dimension string, "depth": overall depth dimension string},
 "columns": number of column symbols you can count,
 "cores": [{"label": label as printed, "bays": how many grid bays it spans}],
 "lifts": number of lift/elevator shafts, "stairs": number of stairs,
 "levels": {"aboveGrade": number of storeys above grade if stated or countable, "belowGrade": number of basement levels, "typicalFloorToFloor": dimension string or "", "overallHeight": dimension string or "", "levelRange": e.g. "11-38" if the plan says which levels it applies to},
 "blocks": [{"label": label of each building block on a site plan, "storeys": number}],
 "structure": one of "steel"|"concrete"|"timber"|"masonry"|"unknown",
 "facade": one of "bronze curtain wall"|"aluminium curtain wall"|"precast"|"brick"|"stone"|"punched windows"|"unknown",
 "notes": [up to 10 general notes or specification lines as printed],
 "components": [up to 16 {"name": short name, "category": one of ${CATEGORIES.join('|')}, "count": integer or null, "notes": short}],
 "confidence": 0 to 1}
Read text carefully. If a value is not on the sheet use null or "". Never guess dimensions.`;

export function parseDim(s) {
  const t = String(s ?? '').replace(/[′’]/g, "'").replace(/[″”]/g, '"');
  let m = t.match(/(\d+)\s*'\s*-?\s*(\d+)?\s*(½|1\/2)?\s*"?/);
  if (m) return ((+m[1]) * 12 + (+m[2] || 0) + (m[3] ? 0.5 : 0)) * 0.0254;
  m = t.match(/^\s*(\d+(?:\.\d+)?)\s*m\s*$/i); if (m) return +m[1];
  m = t.match(/^\s*(\d{3,6})\s*(mm)?\s*$/); if (m) return +m[1] / 1000;
  return null;
}

const int = (v, a, b) => (Number.isFinite(+v) && v !== null && v !== '' ? Math.max(a, Math.min(b, Math.round(+v))) : null);
const str = (v, n) => String(v ?? '').replace(/[\u0000-\u001f<>]/g, ' ').trim().slice(0, n);

// Whitelist the model's answer and add metres for every dimension string it read
export function cleanRead(r) {
  if (!r || typeof r !== 'object') return null;
  const g = r.grid || {}, fp = r.floorPlate || {}, lv = r.levels || {};
  const dim = (s) => { const v = parseDim(s); return v && v > 0.3 && v < 2000 ? { text: str(s, 24), m: Math.round(v * 1000) / 1000 } : null; };
  const pick = (v, list, d) => (list.includes(v) ? v : d);
  const out = {
    sheetType: pick(String(r.sheetType || '').toLowerCase(), ['floor plan', 'site plan', 'section', 'elevation', 'detail', 'other'], 'other'),
    title: str(r.title, 120), sheetNumber: str(r.sheetNumber, 16), scaleText: str(r.scaleText, 30),
    dimensionsRead: (Array.isArray(r.dimensionsRead) ? r.dimensionsRead : []).map((d) => str(d, 24)).filter(Boolean).slice(0, 14),
    grid: { linesAcross: int(g.linesAcross, 2, 40), linesDeep: int(g.linesDeep, 2, 40), bayAcross: dim(g.bayAcross), bayDeep: dim(g.bayDeep) },
    floorPlate: { width: dim(fp.width), depth: dim(fp.depth) },
    columns: int(r.columns, 0, 2000),
    cores: (Array.isArray(r.cores) ? r.cores : []).slice(0, 8).map((c) => ({ label: str(c?.label, 40), bays: int(c?.bays, 0, 20) })).filter((c) => c.label),
    lifts: int(r.lifts, 0, 200), stairs: int(r.stairs, 0, 100),
    levels: { aboveGrade: int(lv.aboveGrade, 1, 200), belowGrade: int(lv.belowGrade, 0, 20), typicalFloorToFloor: dim(lv.typicalFloorToFloor), overallHeight: dim(lv.overallHeight), levelRange: str(lv.levelRange, 20) },
    blocks: (Array.isArray(r.blocks) ? r.blocks : []).slice(0, 10).map((b) => ({ label: str(b?.label, 60), storeys: int(b?.storeys, 1, 200) })).filter((b) => b.label),
    structure: pick(String(r.structure || '').toLowerCase(), ['steel', 'concrete', 'timber', 'masonry', 'unknown'], 'unknown'),
    facade: pick(String(r.facade || '').toLowerCase(), ['bronze curtain wall', 'aluminium curtain wall', 'precast', 'brick', 'stone', 'punched windows', 'unknown'], 'unknown'),
    notes: (Array.isArray(r.notes) ? r.notes : []).map((n) => str(n, 160)).filter(Boolean).slice(0, 10),
    components: (Array.isArray(r.components) ? r.components : []).slice(0, 16).map((c) => ({ name: str(c?.name, 50), category: pick(String(c?.category || '').toLowerCase(), CATEGORIES, 'other'), count: int(c?.count, 0, 100000), notes: str(c?.notes, 100) })).filter((c) => c.name),
    confidence: Number.isFinite(+r.confidence) ? Math.max(0, Math.min(1, +r.confidence)) : null
  };
  // bay sizes printed but not tagged: fall back to the most frequent plausible dimension string
  if (!out.grid.bayAcross || !out.grid.bayDeep) {
    const counts = {};
    for (const d of out.dimensionsRead) { const v = parseDim(d); if (v && v > 3 && v < 15) counts[d] = (counts[d] || 0) + 1; }
    const top = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    if (top) { out.grid.bayAcross ||= dim(top[0]); out.grid.bayDeep ||= dim(top[0]); out.grid.bayFromDimensions = true; }
  }
  return out;
}

export function useful(r) {
  return Boolean(r && (r.grid.linesAcross || r.columns || r.dimensionsRead.length || r.levels.aboveGrade || r.components.length));
}

export async function onRequest({ request, env }) {
  if (request.method !== 'POST') return json({ ok: false, error: 'method_not_allowed' }, 405);
  if (!env?.AI?.run) return json({ ok: false, error: 'ai_unavailable' }, 503);
  let body;
  try { body = await request.json(); } catch { return json({ ok: false, error: 'invalid_json' }, 400); }
  const img = String(body?.image || '');
  if (!/^data:image\/(png|jpeg|webp);base64,/.test(img)) return json({ ok: false, error: 'image_required' }, 400);
  if (img.length > MAX_IMAGE_CHARS) return json({ ok: false, error: 'image_too_large' }, 413);
  const pageText = str(body?.text, 4000);
  const prompt = pageText ? `${PROMPT}\nText extracted from the same page (use it to read dimensions and notes exactly):\n${pageText}` : PROMPT;
  let read = null, lastRaw = '', lastErr = null;
  for (const attempt of [0, 1]) {
    try {
      const raw = await env.AI.run(VISION_MODEL, {
        messages: [
          { role: 'system', content: 'You read architectural drawings. Reply with one JSON object only: no prose, no markdown fences.' },
          { role: 'user', content: [{ type: 'text', text: attempt ? `${prompt}\nKeep strings short. Output the JSON object only.` : prompt }, { type: 'image_url', image_url: { url: img } }] }
        ],
        max_tokens: 2000, temperature: attempt ? 0 : 0.1
      });
      lastRaw = textOf(raw);
      const r = cleanRead(parseJson(raw));
      if (useful(r)) { read = r; break; }
    } catch (err) { lastErr = err; }
  }
  if (!read) {
    console.error('plan-read unreadable', lastErr?.message, lastRaw.slice(0, 300));
    return json({ ok: false, error: lastErr ? 'ai_inference_failed' : 'unreadable_response', detail: String(lastErr?.message || lastRaw).slice(0, 240) }, 502);
  }
  return json({ ok: true, model: VISION_MODEL, read });
}

function json(o, status = 200) { return new Response(JSON.stringify(o), { status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } }); }
